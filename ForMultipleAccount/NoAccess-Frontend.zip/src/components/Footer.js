import React from 'react'

export default function Footer() {
    return (

        <div className="footer-copyright text-center py-3 site-footer" style={{ backgroundColor: 'blue', color: "white", marginTop: "50px", position:"fixed", width:"100%", bottom:"0" }}>© 2021 Copyright @
           <a href="https://mdbootstrap.com/" style={{ color: "white" }}> SaveWithHelpingHands.com</a>
        </div>
    )
}
