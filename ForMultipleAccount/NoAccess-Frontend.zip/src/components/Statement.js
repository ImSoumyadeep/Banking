import React from 'react'

export default function Statement() {
    return (
        <div>
            {/* Fetch data and print in table format */}
        </div>
    )
}
