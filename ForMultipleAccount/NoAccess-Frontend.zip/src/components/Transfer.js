import React, { useEffect } from 'react'
import { useState } from 'react'

export default function Transfer(props) {

    const [recieverId, setrecieverId] = useState('')
    const [amount, setamount] = useState('')
    const [currency, setcurrency] = useState('')
    const [beneficiary, setbeneficiary] = useState('')

    let id;
    id = props.id;
    let data = { "id": id, "amount": parseFloat(amount), "recieverId": recieverId, "currency": currency }


    // Uncomment ths code to fetch beneficiary list data

    // useEffect(() => {
    //     const url = `http://localhost:8080/getbeneficiary/${id}`;     // Get beneficiary list
    //     fetch(url).then(resp => resp.json())
    //         .then(resp => setbeneficiary(resp))
    // }, []) 



    function transfer() {
        // console.log(data)
        // console.log(JSON.stringify(data))


        if (recieverId && amount && (currency!='')) {

            if (amount <= 0) {
                alert('Please enter a valid amount > 0')
                document.getElementById('amount').value = ''
            }

            else {

                fetch('http://localhost:8080/transfer', {         // link to transfer
                    method: 'POST',
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(data)
                }).then((result) => {
                    result.json().then((resp) => {

                        // alert(result.json())
                        alert(resp)

                        // document.getElementById('receiverid').value = ''
                        document.getElementById('amount').value = ''
                    })
                })
            }
        }
        else {
            alert('Please fill both Account No and amount in required format to proceed the payment!!!')
        }


    }



    return (

        <>
            <div className="App" style={{ marginTop: "50px" }}>
                <h6 className="card-subtitle mb-2 text-muted">{`Amount will be debited from ${id}`}</h6>
            </div>
            <div>
                <div className="container">
                    <div className="input-group mb-3" style={{ marginTop: "50px" }}>
                        <div className="dropdown" style={{marginRight:"350px"}}>
                            <button className="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Select Beneficiary from below list
                            </button>
                            <div className="dropdown-menu" aria-labelledby="dropdownMenu2">
                                {/* Displaying list of beneficiaries from the api data */}
                                {/* {beneficiary.map(element=>{
                                    return(
                                        <button className="dropdown-item" onClick={()=>{setrecieverId(element)}} type="button">{element}</button>
                                    )
                                })} */}
                                <button className="dropdown-item" type="button">Action</button>
                                <button className="dropdown-item" type="button">Action2</button>
                            </div>
                            <span className="badge badge-pill badge-success" style={{color:"white", backgroundColor:"green", marginLeft:"25px"}}>Reciever Currency</span>
                        </div>

                        

                        <input type="number" min="1" step="0.01" className="form-control" placeholder="Enter Amount" aria-label="amount" id="amount" value={amount} onChange={(e) => { setamount(e.target.value) }} required />
                        {/* <span className="input-group-text">INR</span> */}
                        <div className="dropdown dropleft">
                            <button className="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Select Currency
                            </button>
                            <div className="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                <button className="dropdown-item" onClick={()=>{setcurrency('INR')}} type="button">INR</button>
                                <button className="dropdown-item" onClick={()=>{setcurrency('USD')}} type="button">USD</button>
                                <button className="dropdown-item" type="button">Something else here</button>
                            </div>
                        </div>

                    </div>
                </div>
                <div className="container input-group mb-3">
                    <input className="form-check-input rounded" id="checkbox" type="checkbox" value="" id="flexCheckChecked" defaultChecked required />
                    <label className="form-check-label font-monospace text-muted" htmlFor="flexCheckChecked">
                        &nbsp; I have checked the receiver's A/C No and amount before transacting
                    </label>
                </div>
                <div className="container" style={{ marginTop: "20px", paddingBottom: "100px" }}>
                    <button id="transferButton" className="btn btn-dark" onClick={transfer} >Make Payment</button>
                    {/* {(id && amount)?(document.getElementById('transferButton').disabled = false):''} */}
                    {/* {(modal === '1')?(successModal):''} */}
                </div>
            </div>
        </>
    )
}
